## Calendric-lib
[![Downloads](https://pepy.tech/badge/calendric-lib)](https://pepy.tech/project/calendric-lib)
![PyPI - Status](https://img.shields.io/pypi/status/calendric-lib)
[![GitHub issues](https://img.shields.io/github/issues/saadbinmunir/Calendric-lib)](https://github.com/saadbinmunir/Calendric-lib/issues)
[![GitHub stars](https://img.shields.io/github/stars/saadbinmunir/Calendric-lib)](https://github.com/saadbinmunir/Calendric-lib/stargazers)
[![GitHub license](https://img.shields.io/github/license/saadbinmunir/Calendric-lib)](https://github.com/saadbinmunir/Calendric-lib/blob/main/LICENSE)

##  About
Calendric-lib is a creative package for calendrical conversion operations in Python.


# Calendric-lib

[![GitHub issues](https://img.shields.io/github/issues/saadbinmunir/Calendric-lib)](https://github.com/saadbinmunir/Calendric-lib/issues)
[![GitHub forks](https://img.shields.io/github/forks/saadbinmunir/Calendric-lib)](https://github.com/saadbinmunir/Calendric-lib/network)
[![GitHub stars](https://img.shields.io/github/stars/saadbinmunir/Calendric-lib)](https://github.com/saadbinmunir/Calendric-lib/stargazers)
[![GitHub license](https://img.shields.io/github/license/saadbinmunir/Calendric-lib)](https://github.com/saadbinmunir/Calendric-lib/blob/main/LICENSE)

#  About
Calendric-lib is a creative package for calendrical conversion operations in Python.

